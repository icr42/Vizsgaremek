import express, { json, urlencoded } from "express";
import { createPool } from "mysql2";
import { hash as _hash, compare } from "bcrypt";
import session from "express-session";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const SALT_ROUNDS = 10;

const app = express();

// Statikus fájlok (frontend) kiszolgálása
app.use(express.static(path.join(__dirname, "public")));


// JSON body-k fogadása (pl. fetch POST)
app.use(json());

// HTML <form> POST-ok fogadása (application/x-www-form-urlencoded)
app.use(urlencoded({ extended: true }));

// 🔹 Session beállítás
app.use(
  session({
    secret: "nagyon-titkos-jelszo-csereld-ki", // fejlesztéshez jó, élesben legyen erősebb, .env-ből
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      // secure: true, // csak HTTPS-en – fejlesztésnél HTTP-n vagyunk, ezért most ne használd
      maxAge: 1000 * 60 * 60 * 24, // 1 nap
    },
  })
);

// 🔹 Middleware: csak bejelentkezett usernek engedünk tovább
function requireLogin(req, res, next) {
  if (!req.session.user) {
    return res.status(401).json({
      success: false,
      message: "Ehhez a művelethez be kell jelentkezni.",
    });
  }
  next();
}

// 🔹 MySQL kapcsolat (MAMP beállításokkal)
const db = createPool({
  host: "localhost",
  port: 3306, // MAMP MySQL port (általában 8889)
  user: "root",
  password: "root",
  database: "fogpifkalo",
});

// 🔹 Egyszerű teszt endpoint – ellenőrzi, hogy él-e a szerver
app.get("/api/ping", (req, res) => {
  res.json({ message: "BurgerBázis backend él 🚀" });
});

// 🔹 DB teszt endpoint – lefuttat egy egyszerű lekérdezést
app.get("/api/db-test", (req, res) => {
  db.query("SELECT 1 + 1 AS result", (err, rows) => {
    if (err) {
      console.error("DB hiba:", err);
      return res.status(500).json({ error: "Adatbázis hiba" });
    }
    res.json({ db_ok: true, result: rows[0].result });
  });
});

// 🔹 Regisztráció endpoint
app.post("/api/register", (req, res) => {
  const { name, email, password, passwordConfirm } = req.body;

  // 1) Alap validációk
  if (!name || !email || !password || !passwordConfirm) {
    return res
      .status(400)
      .json({ success: false, message: "Minden mező kitöltése kötelező." });
  }

  if (password !== passwordConfirm) {
    return res
      .status(400)
      .json({ success: false, message: "A két jelszó nem egyezik." });
  }

  if (password.length < 8) {
    return res.status(400).json({
      success: false,
      message: "A jelszónak legalább 8 karakter hosszúnak kell lennie.",
    });
  }

  // 2) Megnézzük, foglalt-e már az e-mail
  const checkEmailSql = "SELECT id FROM users WHERE email = ? LIMIT 1";

  db.query(checkEmailSql, [email], (err, rows) => {
    if (err) {
      console.error("DB hiba (email ellenőrzés):", err);
      return res
        .status(500)
        .json({ success: false, message: "Szerver hiba (email ellenőrzés)." });
    }

    if (rows.length > 0) {
      return res.status(400).json({
        success: false,
        message: "Ezzel az e-mail címmel már létezik fiók.",
      });
    }

    // 3) Jelszó hash-elése
    _hash(password, SALT_ROUNDS, (err, hash) => {
      if (err) {
        console.error("Jelszó hash hiba:", err);
        return res
          .status(500)
          .json({ success: false, message: "Szerver hiba (hashelés)." });
      }

      // 4) Új user beszúrása
      const insertSql =
        "INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)";

      db.query(insertSql, [name, email, hash], (err, result) => {
        if (err) {
          console.error("DB hiba (insert user):", err);
          return res
            .status(500)
            .json({ success: false, message: "Szerver hiba (mentés)." });
        }

        // 5) Sikeres regisztráció
        return res.status(201).json({
          success: true,
          message: "Sikeres regisztráció.",
          userId: result.insertId,
        });
      });
    });
  });
});

// 🔹 Bejelentkezés endpoint
app.post("/api/login", (req, res) => {
  const { email, password } = req.body;

  // 1) Alap ellenőrzés
  if (!email || !password) {
    return res
      .status(400)
      .json({ success: false, message: "E-mail és jelszó megadása kötelező." });
  }

  // 2) User keresése az adatbázisban
  const sql =
    "SELECT id, name, email, password_hash FROM users WHERE email = ? LIMIT 1";

  db.query(sql, [email], (err, rows) => {
    if (err) {
      console.error("DB hiba (login select):", err);
      return res
        .status(500)
        .json({ success: false, message: "Szerver hiba (login lekérdezés)." });
    }

    if (rows.length === 0) {
      return res
        .status(400)
        .json({ success: false, message: "Hibás e-mail vagy jelszó." });
    }

    const user = rows[0];

    // 3) Jelszó összehasonlítása a hash-sel
    compare(password, user.password_hash, (err, isMatch) => {
      if (err) {
        console.error("bcrypt hiba (compare):", err);
        return res.status(500).json({
          success: false,
          message: "Szerver hiba (jelszó ellenőrzés).",
        });
      }

      if (!isMatch) {
        return res
          .status(400)
          .json({ success: false, message: "Hibás e-mail vagy jelszó." });
      }

      // 4) Sikeres bejelentkezés → user elmentése a sessionbe
      req.session.user = {
        id: user.id,
        name: user.name,
        email: user.email,
      };

      return res.json({
        success: true,
        message: "Sikeres bejelentkezés.",
        user: req.session.user,
      });
    });
  });
});

// 🔹 Jelenlegi bejelentkezett felhasználó lekérdezése
app.get("/api/me", (req, res) => {
  if (!req.session || !req.session.user) {
    // Nem bejelentkezett
    return res.status(200).json({
      loggedIn: false,
      user: null,
    });
  }

  return res.json({
    loggedIn: true,
    user: {
      id: req.session.user.id,
      name: req.session.user.name,
      email: req.session.user.email,
    },
  });
});


// 🔹 Kosár lekérdezése
app.get("/api/cart", requireLogin, (req, res) => {
  const userId = req.session.user.id;

  const sql = `
    SELECT 
      ci.id,
      ci.product_id,
      ci.quantity,
      p.name,
      p.price,
      (ci.quantity * p.price) AS line_total
    FROM cart_items ci
    JOIN products p ON ci.product_id = p.id
    WHERE ci.user_id = ?
  `;

  db.query(sql, [userId], (err, rows) => {
    if (err) {
      console.error("DB hiba (cart select):", err);
      return res
        .status(500)
        .json({ success: false, message: "Szerver hiba (kosár lekérdezés)." });
    }

    const items = rows;
    const total = items.reduce((sum, item) => sum + Number(item.line_total), 0);

    return res.json({
      success: true,
      items,
      total,
    });
  });
});

// 🔹 Tétel hozzáadása a kosárhoz
app.post("/api/cart/add", requireLogin, (req, res) => {
  const userId = req.session.user.id;
  const { productId, quantity } = req.body;

  const qty = Number(quantity) || 1;

  if (!productId) {
    return res
      .status(400)
      .json({ success: false, message: "productId megadása kötelező." });
  }

  if (qty <= 0) {
    return res
      .status(400)
      .json({
        success: false,
        message: "A mennyiségnek pozitívnak kell lennie.",
      });
  }

  const sql = `
    INSERT INTO cart_items (user_id, product_id, quantity)
    VALUES (?, ?, ?)
    ON DUPLICATE KEY UPDATE quantity = quantity + VALUES(quantity)
  `;

  db.query(sql, [userId, productId, qty], (err, result) => {
    if (err) {
      console.error("DB hiba (cart add):", err);
      return res
        .status(500)
        .json({ success: false, message: "Szerver hiba (kosárhoz adás)." });
    }

    return res.json({
      success: true,
      message: "Termék hozzáadva a kosárhoz.",
    });
  });
});

// 🔹 Kosár ürítése
app.post("/api/cart/clear", requireLogin, (req, res) => {
  const userId = req.session.user.id;

  const sql = "DELETE FROM cart_items WHERE user_id = ?";

  db.query(sql, [userId], (err, result) => {
    if (err) {
      console.error("DB hiba (cart clear):", err);
      return res
        .status(500)
        .json({ success: false, message: "Szerver hiba (kosár ürítés)." });
    }

    return res.json({
      success: true,
      message: "Kosár ürítve.",
    });
  });
});

// 🔹 Egy tétel törlése a kosárból
app.post("/api/cart/remove", requireLogin, (req, res) => {
  const userId = req.session.user.id;
  const { productId } = req.body;

  if (!productId) {
    return res.status(400).json({ success: false, message: "productId megadása kötelező." });
  }

  const sql = "DELETE FROM cart_items WHERE user_id = ? AND product_id = ?";

  db.query(sql, [userId, productId], (err, result) => {
    if (err) {
      console.error("DB hiba (cart remove):", err);
      return res.status(500).json({ success: false, message: "Szerver hiba (kosár tétel törlése)." });
    }

    if (result.affectedRows === 0) {
      return res.json({
        success: false,
        message: "Ez a tétel nem található a kosárban.",
      });
    }

    return res.json({
      success: true,
      message: "Tétel törölve a kosárból.",
    });
  });
});

// 🔹 Rendelés véglegesítése (checkout)
app.post("/api/checkout", requireLogin, (req, res) => {
  const userId = req.session.user.id;

  // 1) Lekérdezzük a user kosarát termékárakkal együtt
  const cartSql = `
    SELECT 
      ci.product_id,
      ci.quantity,
      p.price
    FROM cart_items ci
    JOIN products p ON ci.product_id = p.id
    WHERE ci.user_id = ?
  `;

  db.query(cartSql, [userId], (err, cartRows) => {
    if (err) {
      console.error("DB hiba (checkout - cart select):", err);
      return res.status(500).json({ success: false, message: "Szerver hiba (kosár lekérdezés)." });
    }

    if (cartRows.length === 0) {
      return res.status(400).json({ success: false, message: "A kosarad üres, nincs mit megrendelni." });
    }

    // 2) Összár kiszámolása
    let totalPrice = 0;
    cartRows.forEach(row => {
      totalPrice += Number(row.price) * Number(row.quantity);
    });

    // 3) Új rendelés létrehozása az orders táblában
    const insertOrderSql = `
      INSERT INTO orders (user_id, status, total_price)
      VALUES (?, 'pending', ?)
    `;

    db.query(insertOrderSql, [userId, totalPrice], (err, orderResult) => {
      if (err) {
        console.error("DB hiba (checkout - insert order):", err);
        return res.status(500).json({ success: false, message: "Szerver hiba (rendelés mentése)." });
      }

      const orderId = orderResult.insertId;

      // 4) Rendelés tételek mentése az order_items táblába
      const orderItemsValues = cartRows.map(row => [
        orderId,
        row.product_id,
        row.quantity,
        row.price
      ]);

      const insertItemsSql = `
        INSERT INTO order_items (order_id, product_id, quantity, unit_price)
        VALUES ?
      `;

      db.query(insertItemsSql, [orderItemsValues], (err, itemsResult) => {
        if (err) {
          console.error("DB hiba (checkout - insert order_items):", err);
          return res.status(500).json({ success: false, message: "Szerver hiba (rendelés tételek mentése)." });
        }

        // 5) Kosár ürítése
        const clearCartSql = "DELETE FROM cart_items WHERE user_id = ?";

        db.query(clearCartSql, [userId], (err, clearResult) => {
          if (err) {
            console.error("DB hiba (checkout - clear cart):", err);
            return res.status(500).json({ success: false, message: "Szerver hiba (kosár ürítése)." });
          }

          // 6) Sikeres rendelés
          return res.json({
            success: true,
            message: "Sikeres rendelés! Köszönjük a vásárlást.",
            orderId: orderId,
          });
        });
      });
    });
  });
});

// 🔹 Rendelések lekérdezése a bejelentkezett felhasználónak
app.get("/api/orders", requireLogin, (req, res) => {
  const userId = req.session.user.id;

  const sql = `
    SELECT 
      o.id AS order_id,
      o.created_at,
      o.status,
      o.total_price,
      oi.product_id,
      oi.quantity,
      oi.unit_price,
      p.name AS product_name
    FROM orders o
    JOIN order_items oi ON oi.order_id = o.id
    JOIN products p ON p.id = oi.product_id
    WHERE o.user_id = ?
    ORDER BY o.created_at DESC, o.id DESC
  `;

  db.query(sql, [userId], (err, rows) => {
    if (err) {
      console.error("DB hiba (orders select):", err);
      return res.status(500).json({
        success: false,
        message: "Szerver hiba (rendelések lekérdezése).",
      });
    }

    if (rows.length === 0) {
      return res.json({
        success: true,
        orders: [],
      });
    }

    // Sorok csoportosítása rendelésenként
    const ordersMap = {};

    rows.forEach((row) => {
      const id = row.order_id;
      if (!ordersMap[id]) {
        ordersMap[id] = {
          id: id,
          created_at: row.created_at,
          status: row.status,
          total_price: Number(row.total_price),
          items: [],
        };
      }

      ordersMap[id].items.push({
        product_id: row.product_id,
        name: row.product_name,
        quantity: row.quantity,
        unit_price: Number(row.unit_price),
      });
    });

    const orders = Object.values(ordersMap);

    return res.json({
      success: true,
      orders,
    });
  });
});



// 🔹 Kilépés
app.post("/api/logout", (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      console.error("Session törlés hiba:", err);
      return res
        .status(500)
        .json({ success: false, message: "Nem sikerült kilépni." });
    }

    // opcionálisan: törölhetjük a cookie-t is
    res.clearCookie("connect.sid"); // express-session default cookie neve

    return res.json({ success: true, message: "Sikeres kilépés." });
  });
});

// 🔹 Szerver indítása
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`BurgerBázis backend fut: http://localhost:${PORT}`);
});
