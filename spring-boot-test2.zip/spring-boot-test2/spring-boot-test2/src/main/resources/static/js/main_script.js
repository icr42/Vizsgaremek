function login(username, password) {
    console.log("Logging in...");
    fetch("/api/login", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({
            username: username,
            password: password
        })
    })
    .then(response => response.json())
    .then(data => {
        console.log("Server response:", data);
    })
    .catch(error => console.error("Error:", error));
}

function registration(username, password) {
    console.log("Registering...");
    fetch("/api/register", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({
            username: username,
            password: password
        })
    })
    .then(response => response.json())
    .then(data => {
        console.log("Server response:", data);
    })
    .catch(error => console.error("Error:", error));
}

function registrationButton() {
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
    registration(username, password);
}

function loginButton() {
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
    login(username, password);
}