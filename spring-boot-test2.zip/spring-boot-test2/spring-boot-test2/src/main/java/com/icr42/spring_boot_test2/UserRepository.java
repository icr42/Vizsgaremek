package com.icr42.spring_boot_test2;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    // You can add custom queries here later
    User findByUsername(String username);
}