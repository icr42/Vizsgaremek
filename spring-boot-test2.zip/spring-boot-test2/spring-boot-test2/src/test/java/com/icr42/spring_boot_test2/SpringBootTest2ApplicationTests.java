package com.icr42.spring_boot_test2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootTest2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
